let hour = 22;
if(hour >= 6 || hour < 12){
    console.log('Good Morning!');
}
elseif(12--18){
    console.log('Good Afternoon!');
}
else{
    console.log('Good Night!')
}
