<?php

$months = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
$deletedValue = "March";

echo "All months ";
print_r($months);

foreach ($months as $key => $month) {
    if ($month == $deletedValue) {
        unset($months[$key]);
    }
}

echo "Array after removing '$deletedValue': ";
print_r($months);

?>
