<?php

$count = 1; 

do {
    echo $count . "\n";
    $count++;
} while ($count <= 5);

?>
