
console.log("Display Months Name using For Loop")

var month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

for (var i = 0; i < month.length; i++) {
  console.log(month[i]);
}