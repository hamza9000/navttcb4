<?php
$Time = 8;

if ($Time < 12) {
    echo "Good Morning!";
} else if ($Time >=12 || $Time <=18) {
    echo "Good Afternoon!";
}else {
    echo "Good Night!";
}
?>
