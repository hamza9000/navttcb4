<?php

$rows = 8;
$row = 1;

while ($row <= $rows) {
    $col = 1;
    while ($col <= $row) {
        echo "*";
        $col++;
    }
    echo "\n";
    $row++;
}

$row = $rows - 1;
while ($row >= 1) {
    $col = 1;
    while ($col <= $row) {
        echo "*";
        $col++;
    }
    echo "\n";
    $row--;
}
?>
