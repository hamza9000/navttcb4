<?php
$name = "Hamza Naeem"; 

echo ("My name is:" . $name);
?>