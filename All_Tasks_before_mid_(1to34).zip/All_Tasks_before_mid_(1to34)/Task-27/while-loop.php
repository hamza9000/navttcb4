<?php
$i = 5;
while ($i <= 15) {
    echo ($i ."<br>" . " ");
    $i++;
}
?>
