<?php
$i = 5;
do {
    echo ($i ."<br>". " ");
    $i++;
} while ($i <= 15);
?>
