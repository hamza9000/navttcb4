console.log("Using switch statement for displaying the status of the day")

let day = "Saturday";
switch (day) {
    case "Monday":
        console.log("Today is a rainy day");
        break;
    case "Tuesday":
        console.log("Today is a sunny day");
        break;
    case "Wednesday":
        console.log("Today is a cloudy day");
        break;
    case "Thursday":
        console.log("Today is a good day");
        break;
    case "Friday":
        console.log("Today is an cool day");
        break;
    case "Saturday":
        console.log("Today is a Weekend");
        break;
    case "Sunday":
        console.log("Today is a holiday");
        break;

}